from isl.vqe.fixed_ansatz_vqe import FixedAnsatzVQE
